# NewsPaperFree
Browser extension to read articles on some german newspaper pages for free.
Working in the latest version of Google Chrome and Firefox

Sites that work:
- Hannoversche Allgemeine
- Cellesche Zeitung  
- Neue Presse
- Göttinger Tageblatt
- Peiner Allgemeine Zeitung
- Leipziger Volkszeitung
- Schaumburger Nachrichten
- Wolfsburger Allgemeine/Aller-Zeitung
- Kieler Nachrichten
- Lübecker Nachrichten
- Ostsee Zeitung
- Märkische Allgemeine 

## Installation Firefox
https://addons.mozilla.org/de/firefox/addon/newspaper-free/
